
package Model;

import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author Deshani
 */
public class DBSearch {

    private Statement stmt;
    private ResultSet rs;
    
    public ResultSet searchLogin(String usName){
        
        try{
            
            stmt = DBConnection.getStatementConnection();
            String name = usName;
            
            rs = stmt.executeQuery("SELECT * FROM login WHERE username='" + name + "'");
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return rs;
    }
   


    public ResultSet searchMembers(){
        try{
            stmt = DBConnection.getStatementConnection();
            rs = stmt.executeQuery("SELECT * FROM members");
        }
        catch(Exception e){
            
            
        }
        return rs;
    }   

    public ResultSet searchBooks() {
        try{
            stmt = DBConnection.getStatementConnection();
            rs = stmt.executeQuery("SELECT * FROM books");
        }
        catch(Exception e){
               
        }
        return rs;    
    }
    
    public ResultSet loadBooks() {
       try{
            stmt = DBConnection.getStatementConnection();
            rs = stmt.executeQuery("SELECT bookid FROM books");
        }
        catch(Exception e){
            
            
        }
        
        
        return rs;
    }
    
        public ResultSet loadMembers() {
       try{
            stmt = DBConnection.getStatementConnection();
            rs = stmt.executeQuery("SELECT name FROM members");
        }
        catch(Exception e){
            
            
        }
        
        
        return rs;
    }

    public ResultSet IssuedBooks() {
        try{
            stmt = DBConnection.getStatementConnection();
            rs = stmt.executeQuery("SELECT * FROM book_issued");
        }
        catch(Exception e){
               
        }
        return rs;
    }
    
    
         
}