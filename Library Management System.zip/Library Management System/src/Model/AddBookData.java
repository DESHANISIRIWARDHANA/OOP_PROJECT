/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.Statement;

/**
 *
 * @author Ayesha Deshani
 */
public class AddBookData {

    Statement stmt;
    
    public void AddBook(String uniqueCode, String bookid, String name, String author, String stream, String available) {
        try{
            
            stmt = DBConnection.getStatementConnection();
            stmt.executeUpdate
        ("INSERT INTO books VALUES ('"+uniqueCode+"','"+bookid+"','"+name+"','"+author+"','"+stream+"','"+available+"')");
    }
        catch (Exception e){
            e.printStackTrace();
        }
    }
    
}
