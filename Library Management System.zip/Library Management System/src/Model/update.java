/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Deshani
 */
public class update {
        Statement stmt;
       
    


  
public void updateMember(String nic, String name, String address, String phone, String email) {
    Connection connection = null;
    PreparedStatement statement = null;

    try {
        connection = DBConnection.getConnection();
        statement = connection.prepareStatement("UPDATE members SET nic=?, name=?, address=?, phone=?, email=? WHERE nic=?");

        statement.setString(1, nic);
        statement.setString(2, name);
        statement.setString(3, address);
        statement.setString(4, phone);
        statement.setString(5, email);
        statement.setString(6, nic);

        statement.executeUpdate();
    } catch (SQLException e) {
        System.out.println("SQLException: - " + e);
    } finally {
        try {
            if (statement != null) statement.close();
            if (connection != null) connection.close();
        } catch (SQLException e) {
            System.out.println("SQLException Finally: - " + e);
        }
    }
}



    public void updateBook(String selectedBookID, String bookid, String name, String author, String stream, String available) {
        
        Connection connection = null;
        PreparedStatement statement = null;
   
     
        try {
           // File image = new File("E:/ME.png");

           connection = DBConnection.getConnection();

           statement = connection.prepareStatement("UPDATE books SET id=?, bookid=?, name=?, author=?, stream=?, available=? WHERE id=?");

//  statement.setInt(1, 1);
            statement.setString(1,selectedBookID);
            statement.setString(2,bookid);
            statement.setString(3,name);            
            statement.setString(4,author);
            statement.setString(5,stream);
            statement.setString(6,available);
            statement.setString(7,selectedBookID);
           statement.executeUpdate();
           
        
        
       
        } catch (SQLException e) 
            
        {
            System.out.println("SQLException: - " + e);
        } finally {

            try {
                connection.close();              
                statement.close();
            } catch (SQLException e) {
                System.out.println("SQLException Finally: - " + e);
            }
        } 
    }

    public void updateIssuedBook(String selectedBookID, String bookid, String member, String formattedIssueDate, String formattedReturnDate, String status) {
        
        Connection connection = null;
        PreparedStatement statement = null;
   
     
        try {
           // File image = new File("E:/ME.png");

           connection = DBConnection.getConnection();

           statement = connection.prepareStatement("UPDATE book_issued SET id=?, bookid=?, member=?, issue_date=?, return_date=? , status=? WHERE id=?");

//  statement.setInt(1, 1);
            statement.setString(1,selectedBookID);
            statement.setString(2,bookid);            
            statement.setString(3,member);
            statement.setString(4,formattedIssueDate);
            statement.setString(5,formattedReturnDate);
            statement.setString(6,status);
            statement.setString(7,selectedBookID);
           statement.executeUpdate();
           
        
        
       
        } catch (SQLException e) 
            
        {
            System.out.println("SQLException: - " + e);
        } finally {

            try {
                connection.close();              
                statement.close();
            } catch (SQLException e) {
                System.out.println("SQLException Finally: - " + e);
            }
        } 
    }
        
}
