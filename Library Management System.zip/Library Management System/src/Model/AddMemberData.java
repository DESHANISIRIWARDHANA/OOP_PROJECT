/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.Statement;

/**
 *
 * @author Deshani
 */
public class AddMemberData {
    
    Statement stmt;
    
    public void AddMember (String nic, String name, String address, String phone, String email, String gender){
        try{
            
            stmt = DBConnection.getStatementConnection();
            stmt.executeUpdate
        ("INSERT INTO members VALUES ('"+nic+"','"+name+"','"+address+"','"+phone+"','"+email+"','"+gender+"')");
    }
        catch (Exception e){
            e.printStackTrace();
        }
}    
}
