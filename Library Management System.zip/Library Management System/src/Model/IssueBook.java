/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.Statement;
import java.util.Date;

/**
 *
 * @author Ayesha Deshani
 */
public class IssueBook {

    Statement stmt;
    
    public void IssueMemberBook(String uniqueCode, String bookid, String member, String issueDate, String returnDate, String status) {

        try{
            
            stmt = DBConnection.getStatementConnection();
            stmt.executeUpdate
        ("INSERT INTO book_issued VALUES ('"+uniqueCode+"','"+bookid+"','"+member+"','"+issueDate+"','"+returnDate+"','"+status+"')");
    }
        catch (Exception e){
            e.printStackTrace();
        }

    }

    
}
