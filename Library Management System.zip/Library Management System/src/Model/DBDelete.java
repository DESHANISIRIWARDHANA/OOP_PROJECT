/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.Statement;

/**
 *
 * @author Deshani
 */
public class DBDelete {
    
        Statement stmt;
    public void deleteMember(String name){
        try{
            stmt = DBConnection.getStatementConnection();
            stmt.executeUpdate("delete from members where name='"+name+"'");
            
        }catch (Exception e){
        e.printStackTrace();
    }
}
    
    
    
    
    
    
    
    
        public void deleteLecturer(String name){
        try{
            stmt = DBConnection.getStatementConnection();
            stmt.executeUpdate("delete from addlecturer where name='"+name+"'");
            
        }catch (Exception e){
        e.printStackTrace();
    }
        
        
}
        
         public void deletePayment(String name){
        try{
            stmt = DBConnection.getStatementConnection();
            stmt.executeUpdate("delete from payment where name='"+name+"'");
            
        }catch (Exception e){
        e.printStackTrace();
    }
  
    

}
         
     public void deleteMarks(String stuid){
        try{
            stmt = DBConnection.getStatementConnection();
            stmt.executeUpdate("delete from exam where stuid='"+stuid+"'");
            
        }catch (Exception e){
        e.printStackTrace();
    }
        
        
}

    public void deleteBook(String bookid) {
 try{
            stmt = DBConnection.getStatementConnection();
            stmt.executeUpdate("delete from books where bookid='"+bookid+"'");
            
        }catch (Exception e){
        e.printStackTrace();
    }    }
}
