/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.util.Date;
import javax.swing.JOptionPane;

/**
 *
 * @author Ayesha Deshani
 */
public class BookIssueController {

    public static void IssueBook(String uniqueCode, String bookid, String member, String issueDate, String returnDate, String status) {  
         new Model.IssueBook().IssueMemberBook(uniqueCode, bookid, member, issueDate, returnDate, status);
        
        JOptionPane.showMessageDialog(null, "Book has been issued","Successfull",JOptionPane.INFORMATION_MESSAGE);
    }
    
}
