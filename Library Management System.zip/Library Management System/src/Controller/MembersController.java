/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import javax.swing.JOptionPane;

/**
 *
 * @author Deshani
 */
public class MembersController {
    
    public static void AddMembers (String nic, String name, String address, String phone, String email, String gender){
        
        new Model.AddMemberData().AddMember(nic, name, address, phone, email, gender);
        
        JOptionPane.showMessageDialog(null, "New Member has been inserted","Successfull",JOptionPane.INFORMATION_MESSAGE);
    }
    
}
