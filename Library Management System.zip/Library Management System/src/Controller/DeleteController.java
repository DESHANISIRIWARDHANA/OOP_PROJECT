   /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import javax.swing.JOptionPane;

/**
 *
 * @author Deshani
 */

// controller package

public class DeleteController {
    
        public static void deleteMember(String name){
        new Model.DBDelete().deleteMember(name);
        JOptionPane.showMessageDialog(null, "The Record has been deleted.");
        
    }

    public void deleteBook(String bookid) {
        new Model.DBDelete().deleteBook(bookid);
        JOptionPane.showMessageDialog(null, "The Record has been deleted.");
    }

}
