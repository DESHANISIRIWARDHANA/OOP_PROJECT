/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import javax.swing.JOptionPane;

/**
 *
 * @author Deshani
 */
public class UpdateController {

 public static void updateMember(String nic, String name, String address, String phone, String email)
    { 
        
    new Model.update().updateMember(nic, name, address, phone, email);
    JOptionPane.showMessageDialog(null, "Record has been updated", "Successfull", JOptionPane.INFORMATION_MESSAGE);
  
    } 

    public static void updateBook(String selectedBookID, String bookid, String name, String author, String stream, String available) {
    new Model.update().updateBook(selectedBookID, bookid, name, author, stream, available);
    JOptionPane.showMessageDialog(null, "Record has been updated", "Successfull", JOptionPane.INFORMATION_MESSAGE);    }

    public static void updateIssuedBook(String selectedBookID, String bookid, String member, String formattedIssueDate, String formattedReturnDate, String status) {
    new Model.update().updateIssuedBook(selectedBookID, bookid, member, formattedIssueDate, formattedReturnDate, status);
    JOptionPane.showMessageDialog(null, "Record has been updated", "Successfull", JOptionPane.INFORMATION_MESSAGE);    }
}
