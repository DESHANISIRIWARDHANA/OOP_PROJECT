/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import javax.swing.JOptionPane;

/**
 *
 * @author Ayesha Deshani
 */
public class BooksController {

    public static void AddBooks(String uniqueCode, String bookid, String name, String author, String stream, String available) {
        new Model.AddBookData().AddBook(uniqueCode, bookid, name, author, stream, available);
        
        JOptionPane.showMessageDialog(null, "New Book has been inserted","Successfull",JOptionPane.INFORMATION_MESSAGE);
    }
    
}
